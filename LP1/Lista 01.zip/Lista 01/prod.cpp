#include <iostream> 

int main() {
    int a, b;
    std::cin >> a >> b;

    std::cout << "PROD = " << (a*b) << '\n';
}